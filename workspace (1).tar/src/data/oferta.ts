export type Turno = "Mañana" | "Tarde" | "Noche";
export type Duracion = "Cuatrimestral" | "Anual";
export type IconName =
  | "sierra"
  | "fuego"
  | "rayo"
  | "moto"
  | "tijera"
  | "gorro"
  | "chip"
  | "placa";

export interface Curso {
  id: string;
  codigo: string;
  nombre: string;
  area: string;
  desc: string;
  salida: string;
  duracion: Duracion;
  meses: number;
  turnos: Turno[];
  cupo: number;
  inscriptos: number;
  cert: string;
  img: string;
  icon: IconName;
}

export const CURSOS: Curso[] = [
  {
    id: "carpinteria",
    codigo: "T-01",
    nombre: "Carpintería y Mueblería",
    area: "Madera",
    desc: "Lectura de planos, uniones tradicionales, herrajes y terminaciones. Del tablero al mueble terminado.",
    salida: "Carpintero/a de obra y taller, fabricación de muebles a medida.",
    duracion: "Anual",
    meses: 9,
    turnos: ["Tarde"],
    cupo: 20,
    inscriptos: 14,
    cert: "Certificado oficial · DGE Mendoza",
    img: "https://image.qwenlm.ai/generated-images/ee3a2169-cbce-40d2-b206-c3609fa5d7eb/_result.png",
    icon: "sierra",
  },
  {
    id: "herreria",
    codigo: "T-02",
    nombre: "Herrería y Soldadura",
    area: "Metal",
    desc: "Soldadura eléctrica y MIG, corte, plegado y armado de rejas, portones y estructuras livianas.",
    salida: "Herrero/a soldador/a en talleres metalúrgicos o emprendimiento propio.",
    duracion: "Anual",
    meses: 9,
    turnos: ["Noche"],
    cupo: 18,
    inscriptos: 16,
    cert: "Certificado oficial · DGE Mendoza",
    img: "https://image.qwenlm.ai/generated-images/4cea6970-7ddb-4792-a178-ef7af30cadab/_result.png",
    icon: "fuego",
  },
  {
    id: "electricidad",
    codigo: "T-03",
    nombre: "Electricidad Domiciliaria",
    area: "Energía",
    desc: "Instalaciones según reglamento AEA, tableros, iluminación, puesta a tierra y detección de fallas.",
    salida: "Electricista domiciliario/a, camino a la matrícula habilitante.",
    duracion: "Cuatrimestral",
    meses: 4,
    turnos: ["Mañana", "Tarde"],
    cupo: 24,
    inscriptos: 9,
    cert: "Certificado oficial · DGE Mendoza",
    img: "https://image.qwenlm.ai/generated-images/02c349a2-1543-4fdb-800e-26b681f3713a/_result.png",
    icon: "rayo",
  },
  {
    id: "mecanica",
    codigo: "T-04",
    nombre: "Mecánica de Motocicletas",
    area: "Motor",
    desc: "Motor, transmisión, frenos, carburación e inyección. Diagnóstico con instrumental de taller.",
    salida: "Mecánico/a de motos en concesionarios y talleres de la zona.",
    duracion: "Anual",
    meses: 9,
    turnos: ["Tarde"],
    cupo: 16,
    inscriptos: 11,
    cert: "Certificado oficial · DGE Mendoza",
    img: "https://image.qwenlm.ai/generated-images/ce330433-0157-4e8a-98af-09222b092b82/_result.png",
    icon: "moto",
  },
  {
    id: "peluqueria",
    codigo: "T-05",
    nombre: "Peluquería y Barbería",
    area: "Estética",
    desc: "Corte, colorimetría básica, tratamientos capilares y técnicas de barbería clásica y moderna.",
    salida: "Estilista o barbero/a, con práctica real sobre modelos desde el primer mes.",
    duracion: "Cuatrimestral",
    meses: 4,
    turnos: ["Mañana"],
    cupo: 20,
    inscriptos: 12,
    cert: "Certificado oficial · DGE Mendoza",
    img: "https://image.qwenlm.ai/generated-images/51c9c592-560a-49df-ae56-e96fa7386cc4/_result.png",
    icon: "tijera",
  },
  {
    id: "gastronomia",
    codigo: "T-06",
    nombre: "Gastronomía y Panificación",
    area: "Cocina",
    desc: "Panadería, pastelería de base y cocina regional cuyana. Manipulación segura de alimentos.",
    salida: "Ayudante de cocina, panadero/a o emprendimiento gastronómico propio.",
    duracion: "Anual",
    meses: 9,
    turnos: ["Tarde"],
    cupo: 24,
    inscriptos: 18,
    cert: "Certificado oficial + carnet de manipulación",
    img: "https://image.qwenlm.ai/generated-images/5c1da98c-2868-49b2-820b-6367612de2c9/_result.png",
    icon: "gorro",
  },
  {
    id: "informatica",
    codigo: "T-07",
    nombre: "Reparación de PC y Celulares",
    area: "Tecno",
    desc: "Armado y diagnóstico de PC, flasheo, cambio de módulos y soldadura de componentes SMD.",
    salida: "Técnico/a de servicio técnico, soporte y reparación de dispositivos.",
    duracion: "Cuatrimestral",
    meses: 4,
    turnos: ["Noche"],
    cupo: 20,
    inscriptos: 7,
    cert: "Certificado oficial · DGE Mendoza",
    img: "https://image.qwenlm.ai/generated-images/08db92b0-b246-4a95-a344-fed69e79ff97/_result.png",
    icon: "chip",
  },
  {
    id: "construccion",
    codigo: "T-08",
    nombre: "Construcción en Seco y Revoques",
    area: "Obra",
    desc: "Perfiles, placas de yeso, aislaciones, juntas y terminaciones finas para obra nueva y refacción.",
    salida: "Instalador/a de placa y terminador/a de obra, muy demandado en la región.",
    duracion: "Cuatrimestral",
    meses: 4,
    turnos: ["Mañana"],
    cupo: 18,
    inscriptos: 5,
    cert: "Certificado oficial · DGE Mendoza",
    img: "https://image.qwenlm.ai/generated-images/8ae392cf-907a-4ff8-a30b-7eb76b8838b7/_result.png",
    icon: "placa",
  },
];

export const IMG = {
  hero: "https://image.qwenlm.ai/generated-images/d84fe365-96f3-43bd-902c-b9d15c88cf11/_result.png",
  carpinteria:
    "https://image.qwenlm.ai/generated-images/ee3a2169-cbce-40d2-b206-c3609fa5d7eb/_result.png",
};

export const FERIA = {
  fechaISO: "2026-09-25T17:00:00-03:00",
  fechaTxt: "Viernes 25 · Sábado 26 de septiembre 2026",
  horario: "17:00 a 22:00 h",
  lugar: "Predio Ferial de San Martín · Pabellón Central",
  stand: "Stand N.º 14",
};

export const STATS = [
  { valor: 32, sufijo: "", etiqueta: "años formando manos de la zona este" },
  { valor: 1850, sufijo: "+", etiqueta: "egresados trabajando del oficio" },
  { valor: 12, sufijo: "", etiqueta: "talleres equipados dentro de la escuela" },
  { valor: 82, sufijo: "%", etiqueta: "de inserción laboral al primer año" },
];
