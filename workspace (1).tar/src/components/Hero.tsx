import { useEffect, useState } from "react";
import { CURSOS, FERIA, IMG } from "../data/oferta";
import { useCountdown, useScramble } from "../lib/hooks";
import { IconCheck, IconEngrane, IconFlecha, IconTicket } from "./Icons";

const CHIPS = [
  "Totalmente gratuita",
  "Certificación oficial",
  "Desde los 16 años",
  "Turnos mañana · tarde · noche",
];

function CuentaRegresiva() {
  const t = useCountdown(FERIA.fechaISO);
  const cajas = [
    { n: t.dias, l: "días" },
    { n: t.horas, l: "hrs" },
    { n: t.min, l: "min" },
    { n: t.seg, l: "seg" },
  ];
  return (
    <div>
      <p className="mb-2 font-mono text-[10px] font-semibold uppercase tracking-[0.24em] text-ink/60">
        {t.passed ? "La feria ya está en marcha" : "Cuenta regresiva para la apertura"}
      </p>
      <div className="grid grid-cols-4 gap-1.5">
        {cajas.map((c) => (
          <div key={c.l} className="bg-ink py-2.5 text-center text-tiza">
            <span className="block font-mono text-2xl font-bold tabular-nums">
              {String(c.n).padStart(2, "0")}
            </span>
            <span className="block font-mono text-[9px] uppercase tracking-[0.2em] text-humo">
              {c.l}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function TicketFeria() {
  const filas = [
    { k: "Fecha", v: FERIA.fechaTxt },
    { k: "Horario", v: FERIA.horario },
    { k: "Lugar", v: FERIA.lugar },
    { k: "Stand", v: FERIA.stand },
  ];
  return (
    <div className="group relative rotate-2 border-2 border-ink bg-tiza text-ink shadow-[10px_10px_0_rgba(245,179,1,0.9)] transition-transform duration-500 hover:rotate-0">
      <div className="hazard h-2.5" />
      <div className="p-5 sm:p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-2xl uppercase tracking-wide">Ticket de feria</h2>
          <IconTicket className="h-7 w-7 text-cobre" />
        </div>

        <dl className="mb-5 space-y-2.5">
          {filas.map((f) => (
            <div key={f.k} className="flex items-baseline justify-between gap-4">
              <dt className="font-mono text-[10px] font-semibold uppercase tracking-[0.22em] text-ink/50">
                {f.k}
              </dt>
              <dd className="text-right font-mono text-[13px] font-medium">{f.v}</dd>
            </div>
          ))}
        </dl>

        <CuentaRegresiva />

        <div className="relative my-5">
          <span className="absolute -left-8 top-1/2 h-5 w-5 -translate-y-1/2 rounded-full bg-ink" />
          <span className="absolute -right-8 top-1/2 h-5 w-5 -translate-y-1/2 rounded-full bg-ink" />
          <div className="border-t-2 border-dashed border-ink/30" />
        </div>

        <div className="flex items-center justify-between gap-3">
          <p className="font-mono text-[10px] uppercase leading-relaxed tracking-[0.14em] text-ink/60">
            Entrada libre y gratuita
            <br />
            <span className="font-bold text-cobre">Traé tu DNI y preinscribite</span>
          </p>
          <a
            href="#inscripcion"
            className="shrink-0 border-2 border-ink px-3 py-2 font-mono text-[10px] font-bold uppercase tracking-[0.16em] transition-colors duration-200 hover:bg-ink hover:text-ambar"
          >
            Reservar cupo
          </a>
        </div>
      </div>
    </div>
  );
}

export default function Hero() {
  const titulo = useScramble("APRENDÉ UN OFICIO,", 350);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const id = setTimeout(() => setInView(true), 150);
    return () => clearTimeout(id);
  }, []);

  return (
    <section id="inicio" className="grid-dark relative overflow-hidden bg-ink">
      {/* marca de agua tipográfica */}
      <span
        aria-hidden
        className="outline-text pointer-events-none absolute -bottom-8 left-1/2 -translate-x-1/2 select-none whitespace-nowrap font-display text-[24vw] leading-none opacity-70"
      >
        OFICIOS
      </span>

      <div className="relative mx-auto max-w-7xl px-4 pb-14 pt-32 sm:px-6 sm:pt-40">
        <div className="grid items-start gap-12 lg:grid-cols-12">
          {/* cartel principal */}
          <div className="lg:col-span-7">
            <p className="mb-6 flex flex-wrap items-center gap-3 font-mono text-[11px] font-semibold uppercase tracking-[0.22em] text-humo">
              <span className="blink-dot inline-block h-2 w-2 rounded-full bg-ambar" />
              Feria Educativa del Este Mendocino · {FERIA.stand}
            </p>

            <h1 className="font-display uppercase leading-[0.93] text-tiza">
              <span className="block min-h-[0.93em] text-[13vw] sm:text-7xl lg:text-[5.6rem]">
                {titulo || "\u00A0"}
              </span>
              <span className={`mask-line ${inView ? "is-in" : ""} text-[13vw] sm:text-7xl lg:text-[5.6rem]`}>
                <span style={{ transitionDelay: "650ms" }}>
                  SALÍ A <span className="text-ambar">TRABAJAR</span>
                </span>
              </span>
            </h1>

            <div className="mt-8 max-w-xl border-l-4 border-ambar pl-4 sm:pl-5">
              <p className="font-display text-xl uppercase tracking-wide text-tiza sm:text-2xl">
                Escuela Superior de Oficios «Manuel Belgrano»
              </p>
              <p className="mt-1.5 font-mono text-xs uppercase tracking-[0.2em] text-humo">
                Ciudad de San Martín · Mendoza — Ciclo lectivo 2026
              </p>
            </div>

            <p className="mt-6 max-w-xl text-base leading-relaxed text-tiza/75 sm:text-lg">
              Formación profesional gratuita en <strong className="text-tiza">8 oficios con demanda real</strong> en
              la zona este. 70% de práctica en taller, herramientas de verdad y certificado
              oficial. Pasá por el stand o reservá tu lugar ahora.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <a
                href="#oferta"
                className="group flex items-center gap-3 bg-ambar px-6 py-3.5 font-mono text-xs font-bold uppercase tracking-[0.16em] text-ink transition-all duration-200 hover:-translate-y-1 hover:shadow-[6px_6px_0_rgba(245,179,1,0.35)]"
              >
                Ver la oferta educativa
                <IconFlecha className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1.5" />
              </a>
              <a
                href="#inscripcion"
                className="border-2 border-tiza/30 px-6 py-3 font-mono text-xs font-semibold uppercase tracking-[0.16em] text-tiza transition-colors duration-200 hover:border-ambar hover:text-ambar"
              >
                Cómo inscribirte
              </a>
            </div>

            <ul className="mt-9 flex flex-wrap gap-x-6 gap-y-2.5">
              {CHIPS.map((c) => (
                <li
                  key={c}
                  className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.12em] text-humo"
                >
                  <IconCheck className="h-3.5 w-3.5 text-ambar" />
                  {c}
                </li>
              ))}
            </ul>
          </div>

          {/* ticket */}
          <div className="lg:col-span-5">
            <TicketFeria />
          </div>
        </div>

        {/* franja fotográfica del taller */}
        <div className="relative mt-16 h-[280px] overflow-hidden border border-tiza/15 sm:h-[400px]">
          <img
            src={IMG.hero}
            alt="Estudiante soldando una estructura metálica en el taller de herrería de la escuela"
            className="kenburns h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/10 to-ink/40" />
          <div className="absolute inset-x-0 bottom-0 flex flex-wrap items-end justify-between gap-4 p-5 sm:p-7">
            <p className="flex items-center gap-3 font-mono text-[11px] font-medium uppercase tracking-[0.2em] text-tiza">
              <span className="inline-block h-2.5 w-2.5 bg-ambar" />
              Taller de soldadura · turno noche · Galpón 3
            </p>
            <a
              href="#metodo"
              className="link-rule font-mono text-[11px] font-semibold uppercase tracking-[0.2em] text-ambar"
            >
              Conocé cómo se aprende →
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- cinta transportadora de oficios ---------- */

export function Ticker() {
  const items = [
    ...CURSOS.map((c) => c.nombre),
    "Inscripción ciclo 2026 abierta",
    "Educación gratuita",
  ];
  const Grupo = ({ ariaHidden = false }: { ariaHidden?: boolean }) => (
    <div
      aria-hidden={ariaHidden}
      className="flex shrink-0 items-center gap-8 pr-8"
    >
      {items.map((t) => (
        <span key={t} className="flex items-center gap-8">
          <span className="whitespace-nowrap font-display text-xl uppercase tracking-wide text-ink sm:text-2xl">
            {t}
          </span>
          <IconEngrane className="h-5 w-5 shrink-0 text-ink/70" />
        </span>
      ))}
    </div>
  );
  return (
    <div className="relative z-10 border-y-4 border-ink bg-ambar">
      <div className="marquee overflow-hidden py-3">
        <div className="marquee-track">
          <Grupo />
          <Grupo ariaHidden />
        </div>
      </div>
    </div>
  );
}
