import { STATS } from "../data/oferta";
import { useCountUp, useInView } from "../lib/hooks";

function Stat({ valor, sufijo, etiqueta, delay }: { valor: number; sufijo: string; etiqueta: string; delay: number }) {
  const { ref, inView } = useInView<HTMLDivElement>();
  const n = useCountUp(valor, inView, 1500 + delay);
  return (
    <div
      ref={ref}
      className="flex flex-col items-center gap-2 border-ink/25 px-4 py-9 text-center sm:border-l-2 sm:first:border-l-0"
    >
      <span className="font-display text-5xl leading-none tabular-nums sm:text-6xl">
        {n.toLocaleString("es-AR")}
        <span className="text-cobre">{sufijo}</span>
      </span>
      <span className="max-w-[190px] font-mono text-[10.5px] font-medium uppercase leading-relaxed tracking-[0.14em] text-ink/70">
        {etiqueta}
      </span>
    </div>
  );
}

export default function Stats() {
  return (
    <section className="relative border-y-4 border-ink bg-ambar text-ink">
      <div className="hazard h-2" aria-hidden />
      <div className="mx-auto grid max-w-7xl grid-cols-1 px-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-4">
        {STATS.map((s, i) => (
          <Stat key={s.etiqueta} valor={s.valor} sufijo={s.sufijo} etiqueta={s.etiqueta} delay={i * 150} />
        ))}
      </div>
      <div className="hazard h-2" aria-hidden />
    </section>
  );
}
