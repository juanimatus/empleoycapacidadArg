import { IconArriba, LogoMark } from "./Icons";

const ESCUELA = [
  { href: "#oferta", label: "Oferta educativa 2026" },
  { href: "#metodo", label: "Cómo se aprende" },
  { href: "#inscripcion", label: "Preinscripción" },
  { href: "#egresados", label: "Egresados" },
  { href: "#preguntas", label: "Preguntas frecuentes" },
];

const INSTITUCIONAL = [
  { href: "https://dge.mendoza.gov.ar", label: "Dirección General de Escuelas" },
  { href: "https://www.mendoza.gov.ar", label: "Gobierno de Mendoza" },
  { href: "#contacto", label: "Contacto y ubicación" },
];

export default function Footer() {
  const volverArriba = () => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    window.scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" });
  };

  return (
    <footer className="relative overflow-hidden border-t border-tiza/10 bg-[#0a1510]">
      <div className="mx-auto max-w-7xl px-4 pt-14 sm:px-6">
        <div className="grid gap-10 pb-12 md:grid-cols-12">
          <div className="md:col-span-5">
            <a href="#inicio" className="flex items-center gap-3">
              <LogoMark className="h-11 w-11" />
              <span className="leading-none">
                <span className="block font-display text-xl tracking-wide text-tiza">
                  ESO «MANUEL BELGRANO»
                </span>
                <span className="mt-1 block font-mono text-[10px] uppercase tracking-[0.22em] text-humo">
                  Escuela Superior de Oficios
                </span>
              </span>
            </a>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-tiza/60">
              Formación profesional pública y gratuita en la Ciudad de San Martín, Mendoza.
              Oficios con salida laboral real, certificados oficiales y talleres abiertos a la
              comunidad desde hace más de tres décadas.
            </p>
          </div>

          <div className="md:col-span-3">
            <p className="mb-4 font-mono text-[10px] font-bold uppercase tracking-[0.24em] text-ambar">
              La escuela
            </p>
            <ul className="space-y-2.5">
              {ESCUELA.map((l) => (
                <li key={l.label}>
                  <a href={l.href} className="link-rule text-sm text-tiza/70 hover:text-tiza">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-4">
            <p className="mb-4 font-mono text-[10px] font-bold uppercase tracking-[0.24em] text-ambar">
              Institucional
            </p>
            <ul className="space-y-2.5">
              {INSTITUCIONAL.map((l) => (
                <li key={l.label}>
                  <a
                    href={l.href}
                    target={l.href.startsWith("http") ? "_blank" : undefined}
                    rel={l.href.startsWith("http") ? "noreferrer" : undefined}
                    className="link-rule text-sm text-tiza/70 hover:text-tiza"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
            <button
              onClick={volverArriba}
              className="group mt-7 flex items-center gap-3 border-2 border-tiza/25 px-4 py-2.5 font-mono text-[10px] font-bold uppercase tracking-[0.18em] text-tiza/70 transition-colors hover:border-ambar hover:text-ambar"
            >
              <IconArriba className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-1" />
              Volver arriba
            </button>
          </div>
        </div>
      </div>

      {/* marca tipográfica gigante */}
      <div aria-hidden className="select-none overflow-hidden px-2 leading-none">
        <p className="outline-text whitespace-nowrap text-center font-display text-[11vw] leading-[0.85] opacity-80 transition-opacity duration-500 hover:opacity-100">
          MANUEL BELGRANO
        </p>
      </div>

      <div className="border-t border-tiza/10">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-5 sm:px-6">
          <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-humo">
            © 2026 ESO «Manuel Belgrano» · San Martín, Mendoza
          </p>
          <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-humo">
            Sitio de difusión · <span className="text-ambar">Feria Educativa del Este 2026</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
