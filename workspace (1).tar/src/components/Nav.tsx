import { useEffect, useState } from "react";
import { IconArriba, LogoMark } from "./Icons";

const LINKS = [
  { href: "#oferta", label: "Oferta" },
  { href: "#metodo", label: "El método" },
  { href: "#inscripcion", label: "Inscripción" },
  { href: "#egresados", label: "Egresados" },
  { href: "#preguntas", label: "Preguntas" },
  { href: "#contacto", label: "Contacto" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(h > 0 ? (window.scrollY / h) * 100 : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      {/* franja institucional */}
      <div className="hidden bg-ink3 text-tiza/80 sm:block">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-1.5 font-mono text-[11px] tracking-wide sm:px-6">
          <p>Dirección General de Escuelas · Gobierno de Mendoza</p>
          <p className="flex items-center gap-2">
            <span className="blink-dot inline-block h-1.5 w-1.5 rounded-full bg-ambar" />
            Educación pública · gratuita · con salida laboral
          </p>
        </div>
      </div>

      {/* barra de progreso de lectura */}
      <div className="h-[3px] bg-ink3/40">
        <div
          className="h-full bg-ambar transition-[width] duration-150 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>

      <nav
        className={`border-b transition-colors duration-300 ${
          scrolled
            ? "border-tiza/10 bg-ink/90 backdrop-blur-md"
            : "border-transparent bg-transparent"
        }`}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <a href="#inicio" className="group flex items-center gap-3">
            <LogoMark className="h-10 w-10 shrink-0 transition-transform duration-300 group-hover:rotate-45" />
            <span className="leading-none">
              <span className="block font-display text-lg tracking-wide text-tiza">
                ESO «MANUEL BELGRANO»
              </span>
              <span className="mt-1 block font-mono text-[10px] uppercase tracking-[0.22em] text-humo">
                Escuela de Oficios · San Martín
              </span>
            </span>
          </a>

          <ul className="hidden items-center gap-6 lg:flex">
            {LINKS.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  className="link-rule font-mono text-[11px] font-medium uppercase tracking-[0.18em] text-tiza/75 hover:text-ambar"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-3">
            <a
              href="#inscripcion"
              className="hidden items-center gap-2 border-2 border-ambar bg-ambar px-4 py-2 font-mono text-[11px] font-semibold uppercase tracking-[0.16em] text-ink transition-all duration-200 hover:-translate-y-0.5 hover:bg-transparent hover:text-ambar sm:flex"
            >
              Preinscripción
            </a>
            <button
              onClick={() => setOpen((v) => !v)}
              aria-label={open ? "Cerrar menú" : "Abrir menú"}
              className="flex h-10 w-10 flex-col items-center justify-center gap-1.5 border border-tiza/20 lg:hidden"
            >
              <span
                className={`h-0.5 w-5 bg-tiza transition-transform duration-300 ${
                  open ? "translate-y-2 rotate-45" : ""
                }`}
              />
              <span
                className={`h-0.5 w-5 bg-ambar transition-opacity duration-200 ${
                  open ? "opacity-0" : ""
                }`}
              />
              <span
                className={`h-0.5 w-5 bg-tiza transition-transform duration-300 ${
                  open ? "-translate-y-2 -rotate-45" : ""
                }`}
              />
            </button>
          </div>
        </div>

        {/* menú móvil */}
        <div
          className={`grid overflow-hidden border-t border-tiza/10 bg-ink/95 backdrop-blur-md transition-all duration-300 lg:hidden ${
            open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] border-t-0 opacity-0"
          }`}
        >
          <div className="min-h-0">
            <ul className="space-y-1 px-4 py-4">
              {LINKS.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    onClick={() => setOpen(false)}
                    className="block border-l-2 border-transparent px-3 py-2.5 font-display text-xl uppercase tracking-wide text-tiza transition-colors hover:border-ambar hover:bg-ink2 hover:text-ambar"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
              <li className="pt-2">
                <a
                  href="#inscripcion"
                  onClick={() => setOpen(false)}
                  className="flex items-center justify-center gap-2 bg-ambar px-4 py-3 font-mono text-xs font-semibold uppercase tracking-[0.16em] text-ink"
                >
                  <IconArriba className="h-4 w-4 rotate-90" />
                  Preinscripción 2026
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
  );
}
