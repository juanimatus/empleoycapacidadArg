import { useMemo, useState, type ReactNode } from "react";
import { CURSOS, type Duracion, type Turno } from "../data/oferta";
import { OFICIO_ICONS, IconFlecha } from "./Icons";
import Reveal from "./Reveal";

type FiltroTurno = "Todos" | Turno;
type FiltroDur = "Todas" | Duracion;

const TURNOS: FiltroTurno[] = ["Todos", "Mañana", "Tarde", "Noche"];
const DURACIONES: FiltroDur[] = ["Todas", "Cuatrimestral", "Anual"];

function Chip({
  activo,
  onClick,
  children,
}: {
  activo: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`border-2 px-3.5 py-1.5 font-mono text-[11px] font-semibold uppercase tracking-[0.12em] transition-all duration-200 ${
        activo
          ? "border-ink bg-ink text-ambar shadow-[3px_3px_0_rgba(13,27,20,0.25)]"
          : "border-ink/25 text-ink/60 hover:-translate-y-0.5 hover:border-ink hover:text-ink"
      }`}
    >
      {children}
    </button>
  );
}

export default function Oferta({ onElegir }: { onElegir: (id: string) => void }) {
  const [turno, setTurno] = useState<FiltroTurno>("Todos");
  const [dur, setDur] = useState<FiltroDur>("Todas");

  const filtrados = useMemo(
    () =>
      CURSOS.filter(
        (c) =>
          (turno === "Todos" || c.turnos.includes(turno)) &&
          (dur === "Todas" || c.duracion === dur)
      ),
    [turno, dur]
  );

  return (
    <section id="oferta" className="grid-light relative bg-tiza text-ink">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28">
        {/* encabezado de sección */}
        <Reveal className="flex flex-wrap items-end justify-between gap-6 border-b-4 border-ink pb-8">
          <div>
            <p className="mb-3 font-mono text-[11px] font-bold uppercase tracking-[0.26em] text-cobre">
              01 / La oferta del taller
            </p>
            <h2 className="font-display text-5xl uppercase leading-[0.95] sm:text-6xl lg:text-7xl">
              Ocho oficios,
              <br />
              <span className="text-cobre">una salida laboral</span>
            </h2>
          </div>
          <p className="max-w-sm text-sm leading-relaxed text-ink/70">
            Todas las formaciones son <strong>gratuitas</strong>, presenciales y con certificación
            oficial. Los cupos son limitados y se asignan por orden de preinscripción.
          </p>
        </Reveal>

        {/* filtros */}
        <Reveal delay={80} className="mt-8 flex flex-wrap items-center gap-x-8 gap-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="mr-1 font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-ink/45">
              Turno
            </span>
            {TURNOS.map((t) => (
              <Chip key={t} activo={turno === t} onClick={() => setTurno(t)}>
                {t}
              </Chip>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="mr-1 font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-ink/45">
              Duración
            </span>
            {DURACIONES.map((d) => (
              <Chip key={d} activo={dur === d} onClick={() => setDur(d)}>
                {d}
              </Chip>
            ))}
          </div>
          <p className="ml-auto font-mono text-[11px] uppercase tracking-[0.14em] text-ink/55">
            Mostrando <span className="font-bold text-cobre">{filtrados.length}</span> de{" "}
            {CURSOS.length} formaciones
          </p>
        </Reveal>

        {/* grilla de formaciones */}
        {filtrados.length > 0 ? (
          <div className="mt-10 grid gap-7 md:grid-cols-2 xl:grid-cols-4">
            {filtrados.map((c, i) => {
              const Icono = OFICIO_ICONS[c.icon];
              const ocupacion = Math.round((c.inscriptos / c.cupo) * 100);
              const quedan = c.cupo - c.inscriptos;
              return (
                <Reveal key={c.id} delay={(i % 4) * 70}>
                  <article className="group flex h-full flex-col border-2 border-ink bg-tiza transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[8px_8px_0_rgba(13,27,20,1)]">
                    <div className="relative aspect-[4/3] overflow-hidden border-b-2 border-ink">
                      <img
                        src={c.img}
                        alt={`Taller de ${c.nombre}`}
                        loading="lazy"
                        className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                      />
                      <span className="absolute left-3 top-3 bg-ink px-2 py-1 font-mono text-[10px] font-bold tracking-[0.16em] text-ambar">
                        {c.codigo}
                      </span>
                      <span className="absolute right-3 top-3 flex items-center gap-1.5 bg-ambar px-2 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.12em] text-ink">
                        <Icono className="h-3.5 w-3.5" />
                        {c.area}
                      </span>
                    </div>

                    <div className="flex flex-1 flex-col p-5">
                      <h3 className="font-display text-[1.45rem] uppercase leading-tight">
                        {c.nombre}
                      </h3>
                      <p className="mt-2.5 text-sm leading-relaxed text-ink/70">{c.desc}</p>
                      <p className="mt-3 text-[13px] leading-snug text-ink/80">
                        <span className="font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-cobre">
                          Salida laboral ·{" "}
                        </span>
                        {c.salida}
                      </p>

                      <div className="mt-4 space-y-2 border-t border-ink/15 pt-4 font-mono text-[11px] uppercase tracking-[0.08em] text-ink/70">
                        <div className="flex justify-between gap-3">
                          <span className="text-ink/45">Duración</span>
                          <span className="font-semibold text-ink">
                            {c.meses} meses · {c.duracion}
                          </span>
                        </div>
                        <div className="flex justify-between gap-3">
                          <span className="text-ink/45">Turno</span>
                          <span className="font-semibold text-ink">{c.turnos.join(" y ")}</span>
                        </div>
                      </div>

                      <div className="mt-4">
                        <div className="mb-1.5 flex items-center justify-between font-mono text-[10px] font-semibold uppercase tracking-[0.14em]">
                          <span className="text-ink/45">Cupo {c.cupo}</span>
                          <span className={quedan <= 4 ? "font-bold text-cobre" : "text-ink"}>
                            {quedan <= 4 ? `¡Últimos ${quedan} lugares!` : `Quedan ${quedan} lugares`}
                          </span>
                        </div>
                        <div className="h-2 w-full border border-ink/30 bg-tiza2 p-[2px]">
                          <div
                            className={`h-full transition-all duration-700 ${
                              quedan <= 4 ? "bg-cobre" : "bg-ambar"
                            }`}
                            style={{ width: `${ocupacion}%` }}
                          />
                        </div>
                      </div>

                      <div className="mt-auto pt-5">
                        <p className="mb-3 font-mono text-[10px] uppercase tracking-[0.12em] text-ink/45">
                          {c.cert}
                        </p>
                        <button
                          onClick={() => onElegir(c.id)}
                          className="group/btn flex w-full items-center justify-center gap-2.5 border-2 border-ink px-4 py-2.5 font-mono text-[11px] font-bold uppercase tracking-[0.14em] text-ink transition-colors duration-200 hover:bg-ink hover:text-ambar"
                        >
                          Preinscribirme
                          <IconFlecha className="h-4 w-4 transition-transform duration-300 group-hover/btn:translate-x-1.5" />
                        </button>
                      </div>
                    </div>
                  </article>
                </Reveal>
              );
            })}
          </div>
        ) : (
          <div className="mt-10 border-2 border-dashed border-ink/30 px-6 py-16 text-center">
            <p className="font-display text-2xl uppercase text-ink/70">
              Esa combinación no tiene cursos este ciclo
            </p>
            <p className="mx-auto mt-2 max-w-md text-sm text-ink/60">
              Probá otro turno u otra duración, o acercate al stand: hay alternativas para casi
              todos los horarios.
            </p>
            <button
              onClick={() => {
                setTurno("Todos");
                setDur("Todas");
              }}
              className="mt-6 border-2 border-ink bg-ink px-5 py-2.5 font-mono text-[11px] font-bold uppercase tracking-[0.14em] text-ambar transition-colors hover:bg-transparent hover:text-ink"
            >
              Ver toda la oferta
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
