import type { ReactElement, SVGProps } from "react";
import type { IconName } from "../data/oferta";

type P = SVGProps<SVGSVGElement>;

const base = (props: P) => ({
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.8,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  ...props,
});

/* ---- iconos de oficio ---- */

export const IconSierra = (p: P) => (
  <svg {...base(p)}>
    <path d="M3 15 15.5 4.5a2 2 0 0 1 2.8 0l1.2 1.2a2 2 0 0 1 0 2.8L9 19l-3.2.8A2 2 0 0 1 3.4 17z" />
    <path d="m3 15 2-1M7.5 13l1.6 1.6M10.5 10l1.6 1.6M13.5 7l1.6 1.6" />
    <path d="M16 4.5 19.5 8" />
  </svg>
);

export const IconFuego = (p: P) => (
  <svg {...base(p)}>
    <path d="M4 20 12.5 11.5" />
    <path d="M10.5 9.5 14 6l4 4-3.5 3.5z" />
    <path d="M18.5 3.5c-1 1.2-.4 2.4-1.5 3.5M21 6c-.8 1-.4 2-1.3 2.9" />
    <path d="M3 21h6" />
  </svg>
);

export const IconRayo = (p: P) => (
  <svg {...base(p)}>
    <path d="M13 2 5 13h5l-1 9 8-11h-5z" />
  </svg>
);

export const IconMoto = (p: P) => (
  <svg {...base(p)}>
    <circle cx="5.5" cy="16.5" r="2.8" />
    <circle cx="18.5" cy="16.5" r="2.8" />
    <path d="M8 16.5h4l2.5-4h3" />
    <path d="M12 8.5h3l1 3.5" />
    <path d="M9.5 8.5 8 12l-2.3 3.5" />
  </svg>
);

export const IconTijera = (p: P) => (
  <svg {...base(p)}>
    <circle cx="6" cy="6.5" r="2.5" />
    <circle cx="6" cy="17.5" r="2.5" />
    <path d="M8.2 7.6 20 16M8.2 16.4 20 8" />
  </svg>
);

export const IconGorro = (p: P) => (
  <svg {...base(p)}>
    <path d="M7 13.5A3.5 3.5 0 0 1 6.5 6.6 4.5 4.5 0 0 1 12 4a4.5 4.5 0 0 1 5.5 2.6A3.5 3.5 0 0 1 17 13.5V17H7z" />
    <path d="M7 20h10M10 13.5V17M14 13.5V17" />
  </svg>
);

export const IconChip = (p: P) => (
  <svg {...base(p)}>
    <rect x="7" y="7" width="10" height="10" rx="1.5" />
    <rect x="10.2" y="10.2" width="3.6" height="3.6" />
    <path d="M9 7V4M15 7V4M9 20v-3M15 20v-3M7 9H4M7 15H4M20 9h-3M20 15h-3" />
  </svg>
);

export const IconPlaca = (p: P) => (
  <svg {...base(p)}>
    <rect x="3.5" y="5" width="12" height="14" rx="1" />
    <path d="M3.5 9.7h12M3.5 14.3h12" />
    <path d="M15.5 12h3a2 2 0 0 1 2 2v3.5a1.5 1.5 0 0 1-3 0V14l-2-.6z" />
  </svg>
);

export const OFICIO_ICONS: Record<IconName, (p: P) => ReactElement> = {
  sierra: IconSierra,
  fuego: IconFuego,
  rayo: IconRayo,
  moto: IconMoto,
  tijera: IconTijera,
  gorro: IconGorro,
  chip: IconChip,
  placa: IconPlaca,
};

/* ---- iconos de interfaz ---- */

export const IconFlecha = (p: P) => (
  <svg {...base(p)}>
    <path d="M5 12h14M13 6l6 6-6 6" />
  </svg>
);

export const IconCheck = (p: P) => (
  <svg {...base(p)}>
    <path d="m4.5 12.5 5 5L19.5 7" />
  </svg>
);

export const IconMas = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 5v14M5 12h14" />
  </svg>
);

export const IconPin = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z" />
    <circle cx="12" cy="10" r="2.5" />
  </svg>
);

export const IconReloj = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7v5l3.5 2" />
  </svg>
);

export const IconTel = (p: P) => (
  <svg {...base(p)}>
    <path d="M6 3.5h3l1.5 4.5-2 1.5a12 12 0 0 0 6 6l1.5-2 4.5 1.5v3a2 2 0 0 1-2.2 2A16.5 16.5 0 0 1 4 6a2 2 0 0 1 2-2.5z" />
  </svg>
);

export const IconMail = (p: P) => (
  <svg {...base(p)}>
    <rect x="3.5" y="5.5" width="17" height="13" rx="1.5" />
    <path d="m4.5 7 7.5 6 7.5-6" />
  </svg>
);

export const IconUsuarios = (p: P) => (
  <svg {...base(p)}>
    <circle cx="9" cy="8" r="3.2" />
    <path d="M3.5 19.5a5.5 5.5 0 0 1 11 0" />
    <path d="M15.5 5.4a3.2 3.2 0 0 1 0 5.9M17.5 14.6a5.5 5.5 0 0 1 3 4.9" />
  </svg>
);

export const IconTicket = (p: P) => (
  <svg {...base(p)}>
    <path d="M4 7.5h16v3a1.5 1.5 0 0 0 0 3v3H4v-3a1.5 1.5 0 0 0 0-3z" />
    <path d="M14 7.5v2M14 11v2M14 14.5v2" />
  </svg>
);

export const IconCasco = (p: P) => (
  <svg {...base(p)}>
    <path d="M4 15a8 8 0 0 1 16 0" />
    <path d="M3 15h18v2.5H3z" />
    <path d="M10 7.5V5h4v2.5" />
  </svg>
);

export const IconEngrane = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="3" />
    <path d="M12 3.5v2.2M12 18.3v2.2M3.5 12h2.2M18.3 12h2.2M6 6l1.6 1.6M16.4 16.4 18 18M18 6l-1.6 1.6M7.6 16.4 6 18" />
  </svg>
);

export const IconArriba = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 19V5M6 11l6-6 6 6" />
  </svg>
);

export const LogoMark = (p: P) => (
  <svg viewBox="0 0 40 40" fill="none" {...p}>
    <rect width="40" height="40" rx="8" fill="var(--color-ambar)" />
    <path
      d="M20 8.5l2.6 2.6 3.7-.5.5 3.7 2.6 2.6-2.6 2.6-.5 3.7-3.7-.5L20 31.3l-2.6-2.6-3.7.5-.5-3.7L10.6 22l2.6-2.6.5-3.7 3.7.5z"
      fill="var(--color-ink)"
    />
    <circle cx="20" cy="19.9" r="3.4" fill="var(--color-ambar)" />
    <path d="M18.6 19.9h2.8M20 18.5v2.8" stroke="var(--color-ink)" strokeWidth="1.4" />
  </svg>
);
