import { IMG } from "../data/oferta";
import Reveal from "./Reveal";

const PASOS = [
  {
    n: "01",
    t: "Aprender haciendo",
    d: "El 70% de las horas de clase son en el banco de trabajo. La teoría aparece cuando la necesitás para resolver algo concreto: medir, cortar, soldar, cablear.",
  },
  {
    n: "02",
    t: "Grupos que se conocen",
    d: "Comisiones de entre 16 y 24 personas. El maestro de taller sabe tu nombre, tu ritmo y hasta dónde podés llegar cada semana.",
  },
  {
    n: "03",
    t: "Herramienta de verdad",
    d: "Desde el primer día trabajás con máquinas, insumos y equipos de seguridad iguales a los de un taller real. Nada de maquetas de cartón.",
  },
  {
    n: "04",
    t: "La calle como aula",
    d: "Prácticas en herrerías, obras, salones y talleres mecánicos de San Martín y alrededores. Muchos alumnos se quedan trabajando donde practican.",
  },
  {
    n: "05",
    t: "Papel que vale",
    d: "Certificado oficial de la Dirección General de Escuelas, bolsa de trabajo de la escuela y acompañamiento si querés abrir tu propio taller.",
  },
];

export default function Metodo() {
  return (
    <section id="metodo" className="grid-dark relative bg-ink">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28">
        <div className="grid gap-14 lg:grid-cols-12">
          {/* columna fija */}
          <div className="lg:col-span-5">
            <div className="lg:sticky lg:top-32">
              <Reveal>
                <p className="mb-3 font-mono text-[11px] font-bold uppercase tracking-[0.26em] text-ambar">
                  02 / El método
                </p>
                <h2 className="font-display text-5xl uppercase leading-[0.95] text-tiza sm:text-6xl">
                  Así se aprende
                  <br />
                  un oficio<span className="text-ambar">.</span>
                </h2>
                <p className="mt-6 max-w-md text-base leading-relaxed text-tiza/70">
                  No es un curso teórico: es un taller en funcionamiento dentro de una escuela
                  pública. Entrás sin saber nada y salís con las manos entrenadas, contactos en el
                  rubro y un certificado que abre puertas.
                </p>
              </Reveal>
              <Reveal delay={120} className="mt-9">
                <div className="relative overflow-hidden border border-tiza/20">
                  <img
                    src={IMG.carpinteria}
                    alt="Estudiante cepillando una tabla en el taller de carpintería"
                    loading="lazy"
                    className="kenburns h-64 w-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink/80 to-transparent" />
                  <p className="absolute bottom-3 left-4 flex items-center gap-2.5 font-mono text-[10px] uppercase tracking-[0.18em] text-tiza">
                    <span className="inline-block h-2 w-2 bg-ambar" />
                    Taller de carpintería · banco 4
                  </p>
                </div>
              </Reveal>
            </div>
          </div>

          {/* pasos */}
          <div className="lg:col-span-7">
            <ol>
              {PASOS.map((p, i) => (
                <li key={p.n} className="border-t border-tiza/15">
                  <Reveal delay={i * 60}>
                    <div className="group grid grid-cols-[auto_1fr] gap-5 py-8 transition-transform duration-300 hover:translate-x-2 sm:grid-cols-[110px_1fr] sm:gap-8">
                      <span className="outline-text font-display text-6xl leading-none transition-colors duration-300 group-hover:text-ambar group-hover:[-webkit-text-stroke-color:var(--color-ambar)] sm:text-7xl">
                        {p.n}
                      </span>
                      <div>
                        <h3 className="font-display text-2xl uppercase tracking-wide text-tiza sm:text-3xl">
                          {p.t}
                        </h3>
                        <p className="mt-2.5 max-w-lg leading-relaxed text-tiza/65">{p.d}</p>
                      </div>
                    </div>
                  </Reveal>
                </li>
              ))}
            </ol>
            <Reveal delay={150}>
              <div className="mt-4 flex items-start gap-4 border-l-4 border-ambar bg-ink2 p-5">
                <p className="text-sm italic leading-relaxed text-tiza/80">
                  «El que aprende un oficio nunca más hace fila: la fila la hacen en la puerta de
                  su taller.»
                </p>
                <span className="ml-auto shrink-0 font-mono text-[10px] uppercase tracking-[0.16em] text-humo">
                  — Dicho de pasillo, Galpón 1
                </span>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
