import { useState } from "react";
import { IconMas, IconPin } from "./Icons";
import Reveal from "./Reveal";

const PREGUNTAS = [
  {
    q: "¿Cuánto cuesta estudiar en la escuela?",
    a: "Nada: la matrícula y las clases son gratuitas porque somos una institución pública de la Dirección General de Escuelas de Mendoza. Solo te pedimos ropa de trabajo propia y, en algunas formaciones, elementos personales básicos.",
  },
  {
    q: "¿Qué necesito para inscribirme?",
    a: "Tener 16 años o más, la primaria completa y tu DNI. No se exige secundario completo para ninguna de las ocho formaciones del ciclo 2026.",
  },
  {
    q: "¿Qué certificación recibo al terminar?",
    a: "Un certificado oficial de formación profesional avalado por la DGE Mendoza, con validez en todo el país. En Gastronomía se suma además el carnet de manipulación segura de alimentos.",
  },
  {
    q: "¿Puedo trabajar y estudiar al mismo tiempo?",
    a: "Sí, está pensado para eso. Hay turnos mañana, tarde y noche, con cursadas de 2 a 3 veces por semana según la formación. Más de la mitad de nuestros estudiantes trabaja o estudia otra cosa a la vez.",
  },
  {
    q: "¿La escuela pone las herramientas y los materiales?",
    a: "Sí. Máquinas, herramientas, insumos de práctica y equipos de seguridad los aporta el taller. Vos traés tu ropa de trabajo y las ganas; del resto se encarga la escuela.",
  },
  {
    q: "¿Hay ayuda para conseguir trabajo?",
    a: "La escuela mantiene una bolsa de trabajo activa y convenios con herrerías, obras, salones y talleres mecánicos de la zona. Además acompañamos a quienes quieren abrir su propio emprendimiento con orientación paso a paso.",
  },
  {
    q: "¿Cómo reservo mi cupo durante la feria?",
    a: "Acercate al Stand N.º 14 con tu DNI y completás la ficha en el momento. Si no podés ir, preinscribite desde esta página y confirmá dentro de las 72 horas en la secretaría de la escuela.",
  },
];

export default function Faq() {
  const [abierta, setAbierta] = useState<number | null>(0);

  return (
    <section id="preguntas" className="grid-light relative bg-tiza text-ink">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28">
        <div className="grid gap-14 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <Reveal>
              <p className="mb-3 font-mono text-[11px] font-bold uppercase tracking-[0.26em] text-cobre">
                05 / Preguntas
              </p>
              <h2 className="font-display text-5xl uppercase leading-[0.95] sm:text-6xl">
                Lo que siempre
                <br />
                nos preguntan
              </h2>
              <p className="mt-5 leading-relaxed text-ink/70">
                Si tu duda no está acá, en el stand de la feria la respondemos en persona — o
                escribinos, contestamos todo.
              </p>
            </Reveal>
            <Reveal delay={120}>
              <a
                href="#contacto"
                className="group mt-8 flex items-start gap-4 border-2 border-ink bg-ink p-5 text-tiza transition-all duration-200 hover:-translate-y-1 hover:shadow-[6px_6px_0_rgba(199,91,42,1)]"
              >
                <IconPin className="mt-0.5 h-5 w-5 shrink-0 text-ambar" />
                <span>
                  <span className="block font-display text-lg uppercase tracking-wide">
                    ¿Todavía con dudas?
                  </span>
                  <span className="mt-1 block text-sm text-tiza/70">
                    Mirá dónde estamos y cómo contactarnos →
                  </span>
                </span>
              </a>
            </Reveal>
          </div>

          <div className="lg:col-span-8">
            <ul>
              {PREGUNTAS.map((p, i) => {
                const open = abierta === i;
                return (
                  <li key={p.q} className="border-t-2 border-ink last:border-b-2">
                    <Reveal delay={i * 40}>
                      <button
                        onClick={() => setAbierta(open ? null : i)}
                        aria-expanded={open}
                        className="flex w-full items-center justify-between gap-5 py-5 text-left"
                      >
                        <span
                          className={`font-display text-xl uppercase leading-snug tracking-wide transition-colors duration-200 sm:text-2xl ${
                            open ? "text-cobre" : "text-ink"
                          }`}
                        >
                          {p.q}
                        </span>
                        <span
                          className={`flex h-9 w-9 shrink-0 items-center justify-center border-2 transition-all duration-300 ${
                            open
                              ? "rotate-45 border-cobre bg-cobre text-tiza"
                              : "border-ink/40 text-ink hover:border-ink"
                          }`}
                        >
                          <IconMas className="h-4 w-4" strokeWidth={2.4} />
                        </span>
                      </button>
                      <div
                        className={`grid transition-all duration-400 ease-out ${
                          open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                        }`}
                      >
                        <div className="min-h-0 overflow-hidden">
                          <p className="max-w-2xl pb-6 leading-relaxed text-ink/70">{p.a}</p>
                        </div>
                      </div>
                    </Reveal>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
