import type { CSSProperties, ReactNode } from "react";
import { useInView } from "../lib/hooks";

interface RevealProps {
  children: ReactNode;
  delay?: number;
  className?: string;
  style?: CSSProperties;
}

/** Aparece con desplazamiento suave la primera vez que entra en pantalla. */
export default function Reveal({ children, delay = 0, className = "", style }: RevealProps) {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <div
      ref={ref}
      className={`reveal ${inView ? "is-in" : ""} ${className}`}
      style={{ transitionDelay: `${delay}ms`, ...style }}
    >
      {children}
    </div>
  );
}
