import Reveal from "./Reveal";

const EGRESADOS = [
  {
    frase:
      "Salí del taller de herrería y a los dos meses ya estaba soldando portones por mi cuenta. El primer año laburás con lo que aprendiste, no es verso.",
    nombre: "Jonathan Riquelme",
    dato: "Herrería y Soldadura · Promoción 2024",
    giro: "-rotate-2",
  },
  {
    frase:
      "Estudié de noche, después de mi trabajo en la finca. Hoy soy electricista matriculado y hago instalaciones en todo San Martín.",
    nombre: "Marcos Tejada",
    dato: "Electricidad Domiciliaria · Promoción 2025",
    giro: "rotate-1",
  },
  {
    frase:
      "La escuela me dio el oficio y el empujón: abrí mi peluquería en el barrio con las clientas que hice practicando en el taller.",
    nombre: "Carla Miranda",
    dato: "Peluquería y Barbería · Promoción 2023",
    giro: "-rotate-1",
  },
];

export default function Testimonios() {
  return (
    <section id="egresados" className="relative overflow-hidden bg-ink2">
      <span
        aria-hidden
        className="outline-text pointer-events-none absolute -top-10 right-0 select-none font-display text-[16vw] leading-none opacity-50"
      >
        EGRESADOS
      </span>
      <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28">
        <Reveal className="max-w-2xl">
          <p className="mb-3 font-mono text-[11px] font-bold uppercase tracking-[0.26em] text-ambar">
            04 / Egresados
          </p>
          <h2 className="font-display text-5xl uppercase leading-[0.95] text-tiza sm:text-6xl">
            Lo que cuentan
            <br />
            los que ya <span className="text-ambar">salieron</span>
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-8 md:grid-cols-3">
          {EGRESADOS.map((e, i) => (
            <Reveal key={e.nombre} delay={i * 110}>
              <figure
                className={`group relative flex h-full flex-col border border-tiza/15 bg-ink p-7 transition-all duration-500 hover:-translate-y-2 hover:rotate-0 hover:border-ambar/70 hover:shadow-[0_20px_50px_rgba(0,0,0,0.45)] ${e.giro}`}
              >
                <span
                  aria-hidden
                  className="pointer-events-none absolute -top-7 left-5 font-display text-[90px] leading-none text-ambar/90"
                >
                  «
                </span>
                <blockquote className="mt-8 flex-1 text-[15px] leading-relaxed text-tiza/85">
                  {e.frase}
                </blockquote>
                <figcaption className="mt-7 border-t border-tiza/15 pt-5">
                  <p className="font-display text-lg uppercase tracking-wide text-tiza">
                    {e.nombre}
                  </p>
                  <p className="mt-1 font-mono text-[10.5px] uppercase tracking-[0.14em] text-ambar">
                    {e.dato}
                  </p>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>

        <Reveal delay={200}>
          <p className="mt-12 text-center font-mono text-[11px] uppercase tracking-[0.2em] text-humo">
            +1.850 egresados trabajando en herrerías, obras, talleres y cocinas de la zona este
          </p>
        </Reveal>
      </div>
    </section>
  );
}
