import { FERIA } from "../data/oferta";
import { IconMail, IconPin, IconReloj, IconTel, IconFlecha } from "./Icons";
import Reveal from "./Reveal";

function Mapa() {
  return (
    <div className="relative overflow-hidden border border-tiza/20 bg-ink2">
      <svg viewBox="0 0 440 330" className="block w-full" role="img" aria-label="Mapa esquemático: la escuela sobre Avenida 25 de Mayo, a pocas cuadras de la plaza San Martín">
        <rect width="440" height="330" fill="#0f2118" />
        {/* manzanas / calles */}
        {[70, 150, 230, 310, 390].map((x) => (
          <line key={`v${x}`} x1={x} y1="0" x2={x} y2="330" stroke="#1b3425" strokeWidth="14" />
        ))}
        {[60, 140, 220, 300].map((y) => (
          <line key={`h${y}`} x1="0" y1={y} x2="440" y2={y} stroke="#1b3425" strokeWidth="12" />
        ))}
        {/* Av. 25 de Mayo */}
        <line x1="0" y1="220" x2="440" y2="220" stroke="#f5b301" strokeWidth="5" />
        <text x="14" y="210" fill="rgba(241,239,226,0.6)" fontSize="10" fontFamily="IBM Plex Mono, monospace" letterSpacing="2">
          AV. 25 DE MAYO
        </text>
        {/* plaza */}
        <rect x="90" y="80" width="72" height="72" fill="#24472f" stroke="#2f5c3c" strokeWidth="2" />
        <circle cx="126" cy="116" r="10" fill="#2f5c3c" />
        <text x="90" y="72" fill="rgba(241,239,226,0.55)" fontSize="10" fontFamily="IBM Plex Mono, monospace" letterSpacing="1.5">
          PLAZA SAN MARTÍN
        </text>
        {/* predio ferial */}
        <rect x="318" y="86" width="86" height="58" fill="none" stroke="#f5b301" strokeWidth="2" strokeDasharray="6 5" />
        <text x="318" y="78" fill="rgba(245,179,1,0.85)" fontSize="10" fontFamily="IBM Plex Mono, monospace" letterSpacing="1.5">
          PREDIO FERIAL
        </text>
        {/* escuela */}
        <rect x="246" y="238" width="86" height="56" fill="#f5b301" />
        <text x="246" y="262" fill="#0d1b14" fontSize="11" fontWeight="bold" fontFamily="IBM Plex Mono, monospace" letterSpacing="1">
          ESO «M.B.»
        </text>
        <text x="246" y="278" fill="#0d1b14" fontSize="8.5" fontFamily="IBM Plex Mono, monospace" letterSpacing="1">
          GALPONES 1–4
        </text>
        {/* pin con pulso */}
        <circle cx="289" cy="238" r="9" fill="#f5b301" opacity="0.5" className="pin-pulse" style={{ transformBox: "fill-box", transformOrigin: "center" }} />
        <g transform="translate(289,238)">
          <path d="M0 0c-5-8-9-11-9-16a9 9 0 1 1 18 0c0 5-4 8-9 16z" fill="#f5b301" stroke="#0d1b14" strokeWidth="1.5" />
          <circle cx="0" cy="-16" r="3" fill="#0d1b14" />
        </g>
        {/* recorrido feria → escuela */}
        <path d="M361 144 C340 180, 300 180, 290 214" fill="none" stroke="#c75b2a" strokeWidth="2.5" strokeDasharray="7 6" />
        <text x="300" y="185" fill="#c75b2a" fontSize="9.5" fontFamily="IBM Plex Mono, monospace" letterSpacing="1">
          12 min a pie
        </text>
      </svg>
      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-tiza/15 px-4 py-3">
        <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-humo">
          Mapa esquemático de la Ciudad de San Martín
        </p>
        <a
          href="https://www.google.com/maps/search/?api=1&query=San+Mart%C3%ADn+Mendoza"
          target="_blank"
          rel="noreferrer"
          className="link-rule font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-ambar"
        >
          Abrir en Google Maps →
        </a>
      </div>
    </div>
  );
}

const DATOS = [
  {
    icon: IconPin,
    k: "Dirección",
    v: "Av. 25 de Mayo 1180, Ciudad de San Martín, Mendoza",
  },
  { icon: IconReloj, k: "Horario de secretaría", v: "Lunes a viernes · 8:00 a 21:00 h" },
  { icon: IconTel, k: "Teléfono", v: "(263) 442-1180 · WhatsApp (263) 455-7719" },
  { icon: IconMail, k: "Correo", v: "oficios.belgrano@mendoza.edu.ar" },
];

export default function Contacto() {
  return (
    <section id="contacto" className="grid-dark relative bg-ink">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28">
        <div className="grid gap-12 lg:grid-cols-2">
          <div>
            <Reveal>
              <p className="mb-3 font-mono text-[11px] font-bold uppercase tracking-[0.26em] text-ambar">
                06 / Contacto
              </p>
              <h2 className="font-display text-5xl uppercase leading-[0.95] text-tiza sm:text-6xl">
                Vení a conocer
                <br />
                el taller<span className="text-ambar">.</span>
              </h2>
              <p className="mt-5 max-w-md leading-relaxed text-tiza/70">
                La mejor forma de decidir un oficio es verlo funcionando. Las puertas del taller
                están abiertas todo el año: pasá, preguntá y mirá una clase.
              </p>
            </Reveal>

            <div className="mt-9">
              {DATOS.map((d, i) => (
                <Reveal key={d.k} delay={i * 60}>
                  <div className="flex items-start gap-4 border-b border-tiza/12 py-4.5 transition-colors duration-200 hover:border-ambar/50">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center border border-tiza/20 text-ambar">
                      <d.icon className="h-5 w-5" />
                    </span>
                    <div>
                      <p className="font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-humo">
                        {d.k}
                      </p>
                      <p className="mt-1 text-[15px] font-medium text-tiza">{d.v}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>

            <Reveal delay={250}>
              <div className="mt-8 flex flex-wrap items-center gap-4 border border-tiza/15 bg-ink2 p-5">
                <p className="text-sm leading-relaxed text-tiza/75">
                  <strong className="text-ambar">{FERIA.stand} · Feria Educativa del Este:</strong>{" "}
                  {FERIA.fechaTxt.toLowerCase()} en el {FERIA.lugar.toLowerCase()}.
                </p>
                <a
                  href="#inicio"
                  className="group ml-auto flex shrink-0 items-center gap-2 border-2 border-ambar px-4 py-2 font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-ambar transition-colors hover:bg-ambar hover:text-ink"
                >
                  Ver ticket
                  <IconFlecha className="h-3.5 w-3.5 -rotate-90 transition-transform group-hover:-translate-y-0.5" />
                </a>
              </div>
            </Reveal>
          </div>

          <Reveal delay={120}>
            <Mapa />
          </Reveal>
        </div>
      </div>
    </section>
  );
}
