import { useEffect, useState, type FormEvent } from "react";
import { CURSOS, FERIA, type Turno } from "../data/oferta";
import { IconCheck, IconFlecha } from "./Icons";
import Reveal from "./Reveal";

const PASOS = [
  { t: "Pasá por el stand o la escuela", d: "En la feria nos encontrás en el " + FERIA.stand + ". El resto del año, en la secretaría de la escuela." },
  { t: "Completá la ficha", d: "La del stand o esta misma página. Son dos minutos y no te compromete a nada." },
  { t: "Presentá tu DNI", d: "Con ser mayor de 16 años y tener la primaria completa alcanza. No se pide secundario." },
  { t: "Confirmá y empezá", d: "Te avisamos por teléfono o WhatsApp el día de inicio, el aula y qué traer la primera semana." },
];

const TURNOS: Turno[] = ["Mañana", "Tarde", "Noche"];

interface Resumen {
  folio: string;
  nombre: string;
  curso: string;
  turno: string;
}

export default function Inscripcion({ cursoSel }: { cursoSel: string | null }) {
  const [curso, setCurso] = useState(CURSOS[0].id);
  const [turno, setTurno] = useState<Turno>("Tarde");
  const [resumen, setResumen] = useState<Resumen | null>(null);

  useEffect(() => {
    if (cursoSel) setCurso(cursoSel);
  }, [cursoSel]);

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const c = CURSOS.find((x) => x.id === curso);
    setResumen({
      folio: `MB-2026-${1000 + Math.floor(Math.random() * 9000)}`,
      nombre: String(fd.get("nombre") || ""),
      curso: c?.nombre ?? curso,
      turno,
    });
  };

  return (
    <section id="inscripcion" className="grid-light relative bg-tiza text-ink">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28">
        <div className="grid gap-14 lg:grid-cols-12">
          {/* pasos */}
          <div className="lg:col-span-5">
            <Reveal>
              <p className="mb-3 font-mono text-[11px] font-bold uppercase tracking-[0.26em] text-cobre">
                03 / Inscripción
              </p>
              <h2 className="font-display text-5xl uppercase leading-[0.95] sm:text-6xl">
                Reservá tu
                <br />
                lugar<span className="text-cobre">.</span>
              </h2>
              <p className="mt-5 max-w-md leading-relaxed text-ink/70">
                La preinscripción no tiene costo ni examen de ingreso. Como los cupos son chicos,
                conviene anotarse temprano: en 2025, cinco formaciones cerraron cupo en la primera
                semana.
              </p>
            </Reveal>

            <ol className="mt-10">
              {PASOS.map((p, i) => (
                <li
                  key={p.t}
                  className="relative border-l-2 border-ink/20 pb-8 pl-7 last:border-transparent last:pb-0"
                >
                  <Reveal delay={i * 70}>
                    <span className="absolute -left-[13px] top-0 flex h-6 w-6 items-center justify-center bg-ambar font-mono text-[11px] font-bold text-ink">
                      {i + 1}
                    </span>
                    <h3 className="font-display text-xl uppercase tracking-wide">{p.t}</h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-ink/65">{p.d}</p>
                  </Reveal>
                </li>
              ))}
            </ol>

            <Reveal delay={200}>
              <div className="mt-9 border-2 border-ink bg-ink p-5 text-tiza">
                <p className="font-mono text-[10px] font-bold uppercase tracking-[0.22em] text-ambar">
                  Importante
                </p>
                <p className="mt-2 text-sm leading-relaxed text-tiza/80">
                  Si te preinscribís por esta página tenés <strong className="text-tiza">72 horas</strong> para
                  confirmar tu cupo en secretaría o en el stand {FERIA.stand} con tu DNI. Si no, el
                  lugar pasa al siguiente de la lista.
                </p>
              </div>
            </Reveal>
          </div>

          {/* ficha */}
          <div className="lg:col-span-7">
            <Reveal delay={100}>
              <div className="border-2 border-ink bg-tiza shadow-[12px_12px_0_rgba(13,27,20,1)]">
                <div className="flex items-center justify-between gap-4 border-b-2 border-ink bg-ink px-5 py-3.5 sm:px-7">
                  <p className="font-mono text-[11px] font-bold uppercase tracking-[0.2em] text-ambar">
                    Ficha de preinscripción
                  </p>
                  <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-tiza/50">
                    Ciclo 2026
                  </p>
                </div>

                {resumen === null ? (
                  <form onSubmit={onSubmit} className="px-5 py-7 sm:px-7">
                    <div className="grid gap-6 sm:grid-cols-2">
                      <div className="sm:col-span-2">
                        <label htmlFor="f-nombre" className="font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-ink/55">
                          Nombre y apellido *
                        </label>
                        <input
                          id="f-nombre"
                          name="nombre"
                          required
                          minLength={4}
                          placeholder="Ej.: Juana Pérez Sosa"
                          className="field"
                        />
                      </div>
                      <div>
                        <label htmlFor="f-dni" className="font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-ink/55">
                          DNI *
                        </label>
                        <input
                          id="f-dni"
                          name="dni"
                          required
                          inputMode="numeric"
                          pattern="[0-9]{6,8}"
                          title="Entre 6 y 8 dígitos, sin puntos"
                          placeholder="35123456"
                          className="field"
                        />
                      </div>
                      <div>
                        <label htmlFor="f-tel" className="font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-ink/55">
                          Teléfono / WhatsApp *
                        </label>
                        <input
                          id="f-tel"
                          name="tel"
                          required
                          inputMode="tel"
                          placeholder="263 412 3456"
                          className="field"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label htmlFor="f-curso" className="font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-ink/55">
                          Formación de interés *
                        </label>
                        <select
                          id="f-curso"
                          value={curso}
                          onChange={(e) => setCurso(e.target.value)}
                          className="field cursor-pointer font-medium"
                        >
                          {CURSOS.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.codigo} · {c.nombre} ({c.duracion.toLowerCase()}, {c.meses} meses)
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <fieldset className="mt-7">
                      <legend className="font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-ink/55">
                        Turno preferido *
                      </legend>
                      <div className="mt-3 grid grid-cols-3 gap-2.5">
                        {TURNOS.map((t) => (
                          <button
                            type="button"
                            key={t}
                            onClick={() => setTurno(t)}
                            aria-pressed={turno === t}
                            className={`border-2 px-3 py-3 font-mono text-[11px] font-bold uppercase tracking-[0.12em] transition-all duration-200 ${
                              turno === t
                                ? "border-ink bg-ink text-ambar shadow-[4px_4px_0_rgba(245,179,1,0.9)]"
                                : "border-ink/25 text-ink/55 hover:-translate-y-0.5 hover:border-ink hover:text-ink"
                            }`}
                          >
                            {t}
                          </button>
                        ))}
                      </div>
                    </fieldset>

                    <button
                      type="submit"
                      className="group mt-8 flex w-full items-center justify-center gap-3 bg-ambar px-6 py-4 font-mono text-xs font-bold uppercase tracking-[0.18em] text-ink transition-all duration-200 hover:-translate-y-1 hover:shadow-[6px_6px_0_rgba(13,27,20,1)]"
                    >
                      Enviar ficha de preinscripción
                      <IconFlecha className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1.5" />
                    </button>
                    <p className="mt-4 text-center font-mono text-[10px] uppercase tracking-[0.12em] text-ink/45">
                      Sin costo · sin compromiso · confirmás con tu DNI
                    </p>
                  </form>
                ) : (
                  <div className="px-5 py-10 text-center sm:px-10">
                    <span className="mx-auto flex h-16 w-16 items-center justify-center bg-ambar">
                      <IconCheck className="h-8 w-8 text-ink" strokeWidth={2.4} />
                    </span>
                    <h3 className="mt-6 font-display text-3xl uppercase sm:text-4xl">
                      ¡Ficha recibida!
                    </h3>
                    <p className="mx-auto mt-3 max-w-md leading-relaxed text-ink/70">
                      {resumen.nombre.split(" ")[0]}, guardá tu número de folio. Te vamos a
                      contactar para confirmar el cupo.
                    </p>
                    <dl className="mx-auto mt-7 max-w-sm space-y-3 border-2 border-dashed border-ink/30 bg-tiza2/60 p-5 text-left">
                      {[
                        ["Folio", resumen.folio],
                        ["Formación", resumen.curso],
                        ["Turno", resumen.turno],
                        ["Válida por", "72 horas"],
                      ].map(([k, v]) => (
                        <div key={k} className="flex justify-between gap-4">
                          <dt className="font-mono text-[10px] font-bold uppercase tracking-[0.18em] text-ink/50">
                            {k}
                          </dt>
                          <dd className="font-mono text-sm font-semibold">{v}</dd>
                        </div>
                      ))}
                    </dl>
                    <button
                      onClick={() => setResumen(null)}
                      className="mt-7 border-2 border-ink px-5 py-2.5 font-mono text-[11px] font-bold uppercase tracking-[0.14em] transition-colors hover:bg-ink hover:text-ambar"
                    >
                      Completar otra ficha
                    </button>
                  </div>
                )}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
