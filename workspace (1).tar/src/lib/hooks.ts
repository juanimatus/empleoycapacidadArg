import { useEffect, useRef, useState } from "react";

export function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState(
    () =>
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onChange = () => setReduced(mq.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  return reduced;
}

const POOL = "█▓▒#%&$@≠*+=<>/\\";

/** Efecto de texto que se "decodifica" carácter a carácter. */
export function useScramble(finalText: string, delay = 0): string {
  const reduced = usePrefersReducedMotion();
  const [out, setOut] = useState(reduced ? finalText : "");

  useEffect(() => {
    if (reduced) {
      setOut(finalText);
      return;
    }
    let interval: ReturnType<typeof setInterval> | undefined;
    const timeout = setTimeout(() => {
      let frame = 0;
      interval = setInterval(() => {
        frame += 1;
        const fixed = Math.max(0, frame - 4);
        if (fixed >= finalText.length) {
          setOut(finalText);
          if (interval) clearInterval(interval);
          return;
        }
        let s = "";
        for (let i = 0; i < finalText.length; i++) {
          const ch = finalText[i];
          if (ch === " " || ch === "\n") s += ch;
          else if (i < fixed) s += ch;
          else s += POOL[Math.floor(Math.random() * POOL.length)];
        }
        setOut(s);
      }, 34);
    }, delay);
    return () => {
      clearTimeout(timeout);
      if (interval) clearInterval(interval);
    };
  }, [finalText, delay, reduced]);

  return out;
}

/** Cuenta regresiva hasta una fecha objetivo (zona horaria local del visitante). */
export function useCountdown(targetISO: string) {
  const target = useRef(new Date(targetISO).getTime());
  const calc = () => {
    const diff = target.current - Date.now();
    const clamped = Math.max(0, diff);
    return {
      passed: diff <= 0,
      dias: Math.floor(clamped / 86_400_000),
      horas: Math.floor((clamped / 3_600_000) % 24),
      min: Math.floor((clamped / 60_000) % 60),
      seg: Math.floor((clamped / 1000) % 60),
    };
  };
  const [t, setT] = useState(calc);
  useEffect(() => {
    const id = setInterval(() => setT(calc), 1000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return t;
}

/** Observa cuándo un elemento entra en pantalla (una sola vez). */
export function useInView<T extends HTMLElement>(threshold = 0.18) {
  const ref = useRef<T | null>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (!("IntersectionObserver" in window)) {
      setInView(true);
      return;
    }
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setInView(true);
          obs.disconnect();
        }
      },
      { threshold, rootMargin: "0px 0px -36px 0px" }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

/** Números que suben hasta su valor final cuando entran en pantalla. */
export function useCountUp(target: number, start: boolean, duration = 1600): number {
  const reduced = usePrefersReducedMotion();
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!start) return;
    if (reduced) {
      setValue(target);
      return;
    }
    let raf = 0;
    const t0 = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - t0) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setValue(Math.round(target * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [start, target, duration, reduced]);
  return value;
}
