import { useCallback, useState } from "react";
import Nav from "./components/Nav";
import Hero, { Ticker } from "./components/Hero";
import Oferta from "./components/Oferta";
import Metodo from "./components/Metodo";
import Stats from "./components/Stats";
import Inscripcion from "./components/Inscripcion";
import Testimonios from "./components/Testimonios";
import Faq from "./components/Faq";
import Contacto from "./components/Contacto";
import Footer from "./components/Footer";

export default function App() {
  const [cursoSel, setCursoSel] = useState<string | null>(null);

  const elegirCurso = useCallback((id: string) => {
    setCursoSel(id);
    const el = document.getElementById("inscripcion");
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    el?.scrollIntoView({ behavior: reduced ? "auto" : "smooth", block: "start" });
  }, []);

  return (
    <div className="min-h-screen bg-ink font-body text-tiza">
      <div className="noise-layer" aria-hidden />
      <Nav />
      <main>
        <Hero />
        <Ticker />
        <Oferta onElegir={elegirCurso} />
        <Metodo />
        <Stats />
        <Inscripcion cursoSel={cursoSel} />
        <Testimonios />
        <Faq />
        <Contacto />
      </main>
      <Footer />
    </div>
  );
}
